package com.roca12.misiontic2022.tiendalostiburones.BO;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TiendaLosTiburonesApplicationTests {

	@Test
	void contextLoads() {
	}

}
