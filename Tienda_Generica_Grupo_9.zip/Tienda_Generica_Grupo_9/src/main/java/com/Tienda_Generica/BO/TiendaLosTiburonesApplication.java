package com.Tienda_Generica.BO;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TiendaLosTiburonesApplication {
	
	//funcion main de todo el proyecto
	public static void main(String[] args) {
		SpringApplication.run(TiendaLosTiburonesApplication.class, args);
	}

}
